function [epsxx0,epsyy0,epsxy0,epszz0,theta]=permittivity_bGO_diag(omega0)
    % this code is to obtain a permittivity at selected frequency
    % omega0 should be integer times 0.5; 
%     omega0=718;
    load('beta_Ga2O3.mat');

f0=1;
% f=0;
    [a,idx]=min(abs(omega-omega0));
    epsxx0=real(eps_xx(idx))+f0*1i*imag(eps_xx(idx));
    epsxy0=real(eps_xy(idx))+f0*1i*imag(eps_xy(idx));
    epsyy0=real(eps_yy(idx))+f0*1i*imag(eps_yy(idx));
    epszz0=real(eps_zz(idx))+f0*1i*imag(eps_zz(idx));

    %  
% %   the following is to diagonalize the real part and find its eigenmatrix
    epsxx0_r=real(epsxx0);    epsxx0_i=imag(epsxx0);
    epsxy0_r=real(epsxy0);    epsxy0_i=imag(epsxy0);
    epsyy0_r=real(epsyy0);    epsyy0_i=imag(epsyy0);
    epsxx0_dr=((epsxx0_r+epsyy0_r)-sqrt((epsxx0_r-epsyy0_r)^2+4*epsxy0_r^2))/2;
    epsyy0_dr=((epsxx0_r+epsyy0_r)+sqrt((epsxx0_r-epsyy0_r)^2+4*epsxy0_r^2))/2;
    R11=sqrt((epsxx0_r-epsyy0_dr)./(epsxx0_dr-epsyy0_dr));
    R21=epsxy0_r./(epsxx0_dr-epsyy0_dr)./R11;
    R=[R11, -R21; R21, R11];
    eps_di=R'*[epsxx0_i,epsxy0_i;epsxy0_i,epsyy0_i]*R;
%     eps_dr=R'*[epsxx0_r,epsxy0_r;epsxy0_r,epsyy0_r]*R;
    epsxx0_di=eps_di(1,1);
    epsxy0_di=eps_di(1,2);
    epsyy0_di=eps_di(2,2);
    epsxx0=epsxx0_dr+1i*epsxx0_di;
    epsxy0=0+f0*1i*epsxy0_di;
    epsyy0=epsyy0_dr+1i*epsyy0_di;
    epszz0=epszz0;    

    theta = acos(R11);

end
