function eps_r = materials(material,ksim,theta)
% matarial is the material you want
% w is frequency in cm^-1
% theta is rotation angle
% coices are 'air', 'cal', 'bgo', 'drude', 'quartz', 'bgod', 'KRS5'

addpath('.\tmm\materials_data')

if strcmp(material,'air')
    eps_r = [1,0,0;0,1,0;0,0,1];
elseif strcmp(material,'calcite_analytical')
    % calcite
    [~,~,epsxx_cal,epsyy_cal,epszz_cal, epsxz_cal] = permittivity_Calcite_analytic(ksim,theta);
%     eps_r = [real(epsxx_cal),0,real(epsxz_cal);0,real(epsyy_cal),0;real(epsxz_cal),0,real(epszz_cal)]; % lossless
    eps_r =[epsxx_cal,0,epsxz_cal;0,epsyy_cal,0;epsxz_cal,0,epszz_cal]; % calcite
elseif strcmp(material,'bgo')
    % bgo
    [epsxx0_bgo,epsyy0_bgo,epsxy0_bgo,epszz0_bgo,~] = permittivity_bGO(ksim);
    eps_r = [epsxx0_bgo,epsxy0_bgo,0;epsxy0_bgo,epsyy0_bgo,0;0,0,epszz0_bgo]; % bgo
elseif strcmp(material,'MoO3')
    % MoO3
    [epsxx0_MoO3,epsyy0_MoO3,epszz0_MoO3] = permittivity_MoO3_analytic(ksim);
    eps_r = diag([epsxx0_MoO3,epsyy0_MoO3,epszz0_MoO3]);
elseif strcmp(material,'quartz')
    % quartz
    [epsxx0_qua,epsyy0_qua,epsxy0_qua,epszz0_qua]=permittivity_Quartz(ksim);
    eps_r =[epsxx0_qua,epsxy0_qua,0;epsxy0_qua,epsyy0_qua,0;0,0,epszz0_qua]; % quartz
elseif strcmp(material,'bgod')
    % doped bgo
    [epsxx_bgod,epsxy_bgod,epsxz_bgod,epsyx_bgod,epsyy_bgod,epsyz_bgod,epszx_bgod,epszy_bgod,epszz_bgod]=permittivity_bGO_doped(ksim);
    eps_r =[epsxx_bgod,epsxy_bgod,epsxz_bgod;epsyx_bgod,epsyy_bgod,epsyz_bgod;epszx_bgod,epszy_bgod,epszz_bgod];
elseif strcmp(material,'drude')
    fsim = physconst('LightSpeed')*ksim*1e2;
    w_p = 28e15; % plasma frequency
    gamma =0; % loss frequency
    eps_m = 1-w_p^2/((2*pi*fsim)^2-1i*gamma*(2*pi*fsim)); 
    eps_r = [eps_m,0,0;0,eps_m,0;0,0,eps_m];
elseif strcmp(material,'KRS5')
    eps_r_ksr5 = (2.37)^2;
    eps_r = [eps_r_ksr5,0,0;0,eps_r_ksr5,0;0,0,eps_r_ksr5];
elseif strcmp(material,'gold_data')
    eps_r_gold = permittivity_gold_data(ksim);
    eps_r = [eps_r_gold,0,0;0,eps_r_gold,0;0,0,eps_r_gold];
elseif strcmp(material,'gold_drude')
    eps_r_gold = permittivity_gold_drude(ksim);
    eps_r = [eps_r_gold,0,0;0,eps_r_gold,0;0,0,eps_r_gold];
elseif strcmp(material,'silica_analytical') % values valid in range [950,1250] 1/cm
    w_l_silica=1220.8;w_t_silica = 1048.7; g_silica = 71.4; e_i_silica = 2.095;
    eps_r_silica = e_i_silica*(ksim^2-w_l_silica^2+1i*ksim*g_silica)/(ksim^2-w_t_silica^2+1i*ksim*g_silica);
    eps_r = [eps_r_silica,0,0;0,eps_r_silica,0;0,0,eps_r_silica];
elseif strcmp(material,'sapphire') % values valid in range [950,1250] 1/cm
    eps_r = (1.4606)^2*diag([1 1 1]);
elseif strcmp(material,'alpha_Al2O3') % values valid in range [950,1250] 1/cm
    [eps_xx,eps_yy,eps_zz]= permittivity_alpha_Al2O3(ksim);
    eps_r = diag([eps_xx,eps_yy,eps_zz]);
elseif strcmp(material,'hBN') 
    eps_r = diag(permittivity_hBN(ksim));
elseif strcmp(material,'SiDoped') 
    eps_r = diag(permittivity_SiDoped(ksim));
elseif strcmp(material,'SiO2') 
    eps_r = diag(permittivity_SiO2(ksim));
end

end

