function [epsxx0, epsyy0, epszz0]=permittivity_SiO2(omega)

eps_hbn = load('../materials_data/eps_SiO2.txt');
freqs = load('../materials_data/freq.txt');

freqs=freqs/2/pi/physconst('LightSpeed')*10^2;

[~,idx]=min(abs(freqs-omega));

epsxx0=eps_hbn(idx);
epsyy0=eps_hbn(idx);
epszz0=eps_hbn(idx);

end







