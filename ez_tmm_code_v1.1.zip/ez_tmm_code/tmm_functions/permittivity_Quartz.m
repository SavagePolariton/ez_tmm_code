function [epsxx0,epsyy0,epsxy0,epszz0]=permittivity_Quartz(omega0)
    % this code is to obtain a permittivity at selected frequency
    % omega0 should be integer times 0.5; 
%     omega0=620;
    load('F:\Research Files\tmm\materials_data\quartz.dat');

        
    omega=1:1500;
    f=1;
    eps_xx=quartz(:,3)+f*1i*quartz(:,4);
    eps_zz=quartz(:,1)+f*1i*quartz(:,2);
    eps_yy=eps_xx;
    eps_xy=0;
    
    [a,idx]=min(abs(omega-omega0));
    epsxx0=eps_zz(idx);
    epsxy0=0;
    epsyy0=eps_xx(idx); 
    epszz0=eps_zz(idx);
    
% figure
% plot(omega,real(eps_xx),'r',omega,real(eps_yy),'b',omega,real(eps_zz),'m')
% yline(0)
end


