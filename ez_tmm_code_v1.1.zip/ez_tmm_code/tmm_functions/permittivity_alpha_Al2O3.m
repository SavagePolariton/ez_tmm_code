function [eps_xx,eps_yy,eps_zz] = permittivity_alpha_Al2O3(omega)

% model for alpha sapphire is based on
% https://doi-org.ezproxy.gc.cuny.edu/10.1103/PhysRevB.61.8187


wTOv=[385,442,569,635]; % [cm-1]
wLOv=[388,480,625,900]; % [cm-1]
gTOv=[3.3,3.1,4.7,5.0]; % [cm-1]
gLOv=[3.1,1.9,5.9,14.7]; % [cm-1]

wTOp=[400,583]; % [cm-1]
wLOp=[512,871]; % [cm-1]
gTOp=[5.3,1]; % [cm-1]
gLOp=[3,15.4]; % [cm-1]

eps_inf_v=3.077;
eps_inf_p=3.072;

eps_v=eps_inf_v*(wLOv(1)^2-omega^2-1i*omega*gLOv(1))/(wTOv(1)^2-omega^2-1i*omega*gTOv(1))*...
                (wLOv(2)^2-omega^2-1i*omega*gLOv(2))/(wTOv(2)^2-omega^2-1i*omega*gTOv(2))*...
                (wLOv(3)^2-omega^2-1i*omega*gLOv(3))/(wTOv(3)^2-omega^2-1i*omega*gTOv(3))*...
                (wLOv(4)^2-omega^2-1i*omega*gLOv(4))/(wTOv(4)^2-omega^2-1i*omega*gTOv(4));

eps_p=eps_inf_p*(wLOp(1)^2-omega^2-1i*omega*gLOp(1))/(wTOp(1)^2-omega^2-1i*omega*gTOp(1))*...
                (wLOp(2)^2-omega^2-1i*omega*gLOp(2))/(wTOp(2)^2-omega^2-1i*omega*gTOp(2));


% c-plane alpha_sapphire
eps_xx = eps_v;
eps_yy = eps_v;
eps_zz = eps_p;

% a-plane alpha_sapphire
% eps_xx = eps_p;
% eps_yy = eps_v;
% eps_zz = eps_v;

end





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % plot permittivity
% 
% omega=linspace(200,1000,1e3);
% 
% wTOv=[385,442,569,635]; % [cm-1]
% wLOv=[388,480,625,900]; % [cm-1]
% gTOv=[3.3,3.1,4.7,5.0]; % [cm-1]
% gLOv=[3.1,1.9,5.9,14.7]; % [cm-1]
% 
% wTOp=[400,583]; % [cm-1]
% wLOp=[512,871]; % [cm-1]
% gTOp=[5.3,1]; % [cm-1]
% gLOp=[3,15.4]; % [cm-1]
% 
% eps_inf_v=3.077;
% eps_inf_p=3.072;
% 
% eps_v=eps_inf_v*(wLOv(1)^2-omega.^2-1i*omega*gLOv(1))./(wTOv(1).^2-omega.^2-1i*omega*gTOv(1)).*...
%                 (wLOv(2)^2-omega.^2-1i*omega*gLOv(2))./(wTOv(2).^2-omega.^2-1i*omega*gTOv(2)).*...
%                 (wLOv(3)^2-omega.^2-1i*omega*gLOv(3))./(wTOv(3).^2-omega.^2-1i*omega*gTOv(3)).*...
%                 (wLOv(4)^2-omega.^2-1i*omega*gLOv(4))./(wTOv(4).^2-omega.^2-1i*omega*gTOv(4));
% 
% eps_p=eps_inf_p*(wLOp(1)^2-omega.^2-1i*omega*gLOp(1))./(wTOp(1).^2-omega.^2-1i*omega*gTOp(1)).*...
%                 (wLOp(2)^2-omega.^2-1i*omega*gLOp(2))./(wTOp(2).^2-omega.^2-1i*omega*gTOp(2));
% 
% 
% % c-plane alpha_sapphire
% eps_xx = eps_v;
% eps_yy = eps_v;
% eps_zz = eps_p;
% 
% 
% 
% figure
% plot(omega,eps_v,omega,eps_p,'--')
% 
% 
% 
