function [epsxx0, epsyy0, epszz0]=permittivity_MoO3_analytic(omega)
% omega=380:0.2:1050; %cm-1
eps_x_inf=4; eps_y_inf=5.2; eps_z_inf=2.4;
TO=[820;545;958];
LO=[972;851;1004];
Gamma=[4;4;2];

epsxx0=eps_x_inf*(1+(LO(1)^2-TO(1)^2)./(TO(1)^2-omega.^2-1i*Gamma(1)*omega));
epsyy0=eps_y_inf*(1+(LO(2)^2-TO(2)^2)./(TO(2)^2-omega.^2-1i*Gamma(2)*omega));
epszz0=eps_z_inf*(1+(LO(3)^2-TO(3)^2)./(TO(3)^2-omega.^2-1i*Gamma(3)*omega));

% figure
% plot(omega,epsxx0,'b',omega,epsyy0,'r',omega,epszz0,'m')
% legend('$\epsilon_{xx}$','$\epsilon_{yy}$','$\epsilon_{zz}$')
% xlim([750 900])
% xlabel('Frequency (cm^{-1}')
% ylabel('Real permittivity')
% set(gca,'FontName','Times New Roman','FontSize',24)
end






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%
% clear all
% close all
% clc
% 
% set(groot,'defaulttextinterpreter','latex');
% set(0,'defaultAxesFontSize',16)
% set(0,'defaultLegendFontSize',16)
% set(groot, 'defaultLegendInterpreter','latex');
% set(groot, 'defaultAxesTickLabelInterpreter','latex');
% set(groot, 'defaultLegendInterpreter','latex');
% 
% %%
% % % calculate opening angle
% % oms=linspace(700,1200,2e3);
% % for ii=1:length(oms)
% %     omega=oms(ii);
% %     eps_x_inf=4; eps_y_inf=5.2; eps_z_inf=2.4;
% %     TO=[820;545;958];
% %     LO=[972;851;1004];
% %     Gamma=[4;4;2];
% % 
% %     epsxx0=eps_x_inf*(1+(LO(1)^2-TO(1)^2)./(TO(1)^2-omega.^2-1i*Gamma(1)*omega));
% %     epsyy0=eps_y_inf*(1+(LO(2)^2-TO(2)^2)./(TO(2)^2-omega.^2-1i*Gamma(2)*omega));
% %     epszz0=eps_z_inf*(1+(LO(3)^2-TO(3)^2)./(TO(3)^2-omega.^2-1i*Gamma(3)*omega));
% % 
% %     if (real(epsxx0)<=0 && real(epsyy0)>=0)||(real(epsxx0)>=0 && real(epsyy0)<=0)
% %         theta(ii)=pi/2-atan(sqrt(-real(epsxx0)/real(epsyy0)));
% %     else
% %         theta(ii)=NaN;
% %     end
% % end
% % 
% % figure
% % plot(oms,theta*180/pi)
% % xlabel('$\omega$ [1/cm]'),ylabel('power flow angle')
% % box on
% % axis square
% 
% %%
% 
% % plot permittivity components
% c0=physconst('LightSpeed');
% oms=linspace(750,1000,2e3);
% for ii=1:length(oms)
%     omega=oms(ii);
%     eps_x_inf=4; eps_y_inf=5.2; eps_z_inf=2.4;
%     TO=[820;545;958];
%     LO=[972;851;1004];
%     Gamma=[4;4;2];
% 
%     epsxx0(ii)=eps_x_inf*(1+(LO(1)^2-TO(1)^2)./(TO(1)^2-omega.^2-1i*Gamma(1)*omega));
%     epsyy0(ii)=eps_y_inf*(1+(LO(2)^2-TO(2)^2)./(TO(2)^2-omega.^2-1i*Gamma(2)*omega));
%     epszz0(ii)=eps_z_inf*(1+(LO(3)^2-TO(3)^2)./(TO(3)^2-omega.^2-1i*Gamma(3)*omega));
% 
% end
% 
% figure
% hold on
% plot(oms,real(epsxx0),oms,imag(epsxx0))
% plot(oms,real(epsyy0),oms,imag(epsyy0))
% plot(oms,real(epszz0),oms,imag(epszz0))
% 
% T=[oms'*c0*100,real(epsxx0)',imag(epsxx0)',real(epsyy0)',imag(epsyy0)',real(epszz0)',imag(epszz0)'];
% writematrix(T,'eps_MoO3_850_940.txt','Delimiter',' ');
