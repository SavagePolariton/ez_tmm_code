function [epsxx,epsxy,epsxz,epsyx,epsyy,epsyz,epszx,epszy,epszz]=permittivity_bGO_doped(omega0)

n_matrix = load('bGOepsN18p9i.txt'); % change this name accordingly

omega = n_matrix(:,1);

[~,idx]=min(abs(omega-omega0));

data = n_matrix(idx,2:end);

epsxx = (data(1)^2-data(2)^2)+1i*2*data(1)*data(2);
epsxy = (data(3)^2-data(4)^2)+1i*2*data(3)*data(4);
epsxz = (data(5)^2-data(6)^2)+1i*2*data(5)*data(6);

epsyx = (data(7)^2-data(8)^2)+1i*2*data(7)*data(8);
epsyy = (data(9)^2-data(10)^2)+1i*2*data(9)*data(10);
epsyz = (data(11)^2-data(12)^2)+1i*2*data(11)*data(12);

epszx = (data(13)^2-data(14)^2)+1i*2*data(13)*data(14);
epszy = (data(15)^2-data(16)^2)+1i*2*data(15)*data(16);
epszz = (data(17)^2-data(18)^2)+1i*2*data(17)*data(18);

end

