function [eps_r]=permittivity_gold_drude(omega0)
    % this code is to obtain a permittivity at selected frequency
    % omega0 is in 1/cm
    
    om = 2*pi*physconst('LightSpeed')*omega0*1e2;

    epsInfAu = 10.41;
    gamAu = 0.407e15;
    ompAu = 13.7e15;
    eps_r = epsInfAu - ompAu^2./(om.*(om+1i*gamAu));

end
