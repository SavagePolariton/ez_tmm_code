function [eps_r]=permittivity_gold_data(omega0)
    % this code is to obtain a permittivity at selected frequency
    % omega0 should be integer times 0.5; 
    % omega0 is in 1/cm

    addpath('./tmm/materials_data')
    n_index = load('gold_baber-weaver.txt');

    f=physconst('LightSpeed')*omega0*1e2;
    l = physconst('LightSpeed')/f*1e6;
    l_meas = n_index(:,1); 
    x=linspace(1,length(l_meas),length(l_meas));xq = linspace(1,length(l_meas),2e3);
    % interpolate data
    l_meas = spline(x,l_meas,xq);
    nn = spline(x,n_index(:,2),xq);
    kk = spline(x,n_index(:,3),xq);

    % find value
    [~,idx]=min(abs(l-l_meas));
    n = nn(idx); k = kk(idx);

    eps_r = (n^2-k^2)+1i*2*n*k;

end
