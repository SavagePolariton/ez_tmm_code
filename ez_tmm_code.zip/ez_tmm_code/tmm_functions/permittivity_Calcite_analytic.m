function [eps_v, eps_p, epsxx0, epsyy0, epszz0, epsxz0]=permittivity_Calcite_analytic(omega,theta)
N_digit=6;
phi=pi/2-theta/180*pi;
eps_v_inf=2.7; eps_p_inf=2.4; 
TO=[1410;712;871];
LO=[1550;715;890];     
Gamma=[10;5;3];
     
eps_v= eps_v_inf*(1+(LO(1)^2-TO(1)^2)/(TO(1)^2-omega^2-1i*Gamma(1)*omega)+...
+(LO(2)^2-TO(2)^2)/(TO(2)^2-omega^2-1i*Gamma(2)*omega));
eps_p=eps_p_inf*(1+(LO(3)^2-TO(3)^2)/(TO(3)^2-omega^2-1i*Gamma(3)*omega));

epsxx=eps_v;epsyy=eps_v;epszz=eps_p;

% epsxx=1;epsyy=1;epszz=2;

% coordinate transformation 
epsxx0=1/2*(epsxx+epszz+(epsxx-epszz)*round(cos(2*phi),N_digit));
epszz0=1/2*(epsxx+epszz+(-epsxx+epszz)*round(cos(2*phi),N_digit));
epsxz0=-(epszz-epsxx)*round(cos(phi),N_digit)*round(sin(phi),N_digit);
epsyy0=epsyy;

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% clc
% close all
% clear all
% 
% omega=linspace(1400,1500,2e3)
% theta=23.3;
% N_digit=6;
% phi=pi/2-theta/180*pi;
% eps_v_inf=2.7; eps_p_inf=2.4; 
% TO=[1410;712;871];
% LO=[1550;715;890];     
% Gamma=[10;5;3];
%      
% eps_v= eps_v_inf*(1+(LO(1)^2-TO(1)^2)./(TO(1)^2-omega.^2-1i*Gamma(1)*omega)+...
% +(LO(2)^2-TO(2)^2)./(TO(2)^2-omega.^2-1i*Gamma(2)*omega));
% eps_p=eps_p_inf*(1+(LO(3)^2-TO(3)^2)./(TO(3)^2-omega.^2-1i*Gamma(3)*omega));
% 
% epsxx=eps_v;epsyy=eps_v;epszz=eps_p;
% 
% % epsxx=1;epsyy=1;epszz=2;
% 
% % coordinate transformation 
% epsxx0=1/2*(epsxx+epszz+(epsxx-epszz)*round(cos(2*phi),N_digit));
% epszz0=1/2*(epsxx+epszz+(-epsxx+epszz)*round(cos(2*phi),N_digit));
% epsxz0=-(epszz-epsxx)*round(cos(phi),N_digit)*round(sin(phi),N_digit);
% epsyy0=epsyy;
% 
% figure, hold on
% plot(omega,real(epsxx0),omega,imag((epsxx0)))
% plot(omega,real(epsyy0),omega,imag((epsyy0)))
% plot(omega,real(epszz0),omega,imag((epszz0)))