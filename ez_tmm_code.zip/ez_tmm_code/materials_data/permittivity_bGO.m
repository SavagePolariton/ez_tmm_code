function [epsxx0,epsyy0,epsxy0,epszz0,f]=permittivity_bGO(omega0)
    % this code is to obtain a permittivity at selected frequency
    % omega0 should be integer times 0.5; 
    %     omega0=718;
    addpath('.\tmm\materials_data')
    load('beta_Ga2O3.mat');
    f=3e8*omega0*1e-2;
    f0=1;
    % f=0;
    [~,idx]=min(abs(omega-omega0));
    epsxx0=real(eps_xx(idx))+f0*1i*imag(eps_xx(idx));
    epsxy0=real(eps_xy(idx))+f0*1i*imag(eps_xy(idx));
    epsyy0=real(eps_yy(idx))+f0*1i*imag(eps_yy(idx));
    epszz0=real(eps_zz(idx))+f0*1i*imag(eps_zz(idx));
end
