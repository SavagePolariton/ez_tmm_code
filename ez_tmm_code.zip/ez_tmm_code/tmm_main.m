clc
clear all
close all
%
%
set(groot,'defaulttextinterpreter','latex');
set(0,'defaultAxesFontSize',16)
set(0,'defaultLegendFontSize',16)
set(groot, 'defaultLegendInterpreter','latex');
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex');
%
addpath('.\tmm\tmm_functions')
addpath('.\tmm\materials_data')
%
format long
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% Define constants
c=physconst('LightSpeed'); % [m/s]
mu0=4*pi*10^-7; %[H/m]
eps0=1/(mu0*c^2); %[F/m]
Z0=sqrt(mu0/eps0); % vacuum impedance [Ohm]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% Setup frequency
ksim=889; % [1/cm]
lam=1/(ksim*1e2); % [m]
k0=2*pi/lam;
om=2*pi*ksim*1e2*physconst('LightSpeed');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% Setup momentum space scanning area
IPArange=[0 90];  % normalized to k_0
NpointsIPA=1.1e2;
inPlaneAngles=linspace(IPArange(1),IPArange(2),NpointsIPA); % (deg)
krange=[1e-4 20];  % normalized to k_0
Npoints=2.5e2;
krs=linspace(krange(1),krange(2),Npoints(1));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% Setup materials
Nlayers=6; % number of layers includes super- and substrate
EPSR=zeros(3,3,Nlayers);d=zeros(1,Nlayers); % do not touch
%
fraction=0.44;
%
% input layer thickness
%%%
d(1)=0; % always zero - first layers
%%%
% customize thickness
d(2)=0.3e-6;
d(3)=0.35e-6;
d(4)=1/(88900)/4/1.8;
d(5)=50e-9;
%%%
d(end)=0; % alsays zero - last layer
%
%
EPSR(:,:,1)=(1+1i*1e-8)*diag([1,1,1]);
EPSR(:,:,2)=(16*fraction+1*(1-fraction)+1i*1e-8)*diag([1,1,1]);
EPSR(:,:,3)=real(materials('MoO3',ksim,0))+1i*1*imag(materials('MoO3',ksim,0));
EPSR(:,:,4)=1.8^2*(1+1i*1e-8)*diag([1,1,1]);
EPSR(:,:,5)=materials('gold_data',ksim,0);
EPSR(:,:,end)=1.8^2*(1+1i*1e-8)*diag([1,1,1]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% Setup polarization
pol='p'; % either p- or s-
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% END SETUP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% Configuration variables - DO NOT TOUCH
N_round=4; % this number is needed to truncate the imaginary part of each eigenvalue in sorting process
U=zeros(16,Npoints(1),Nlayers);G=U;T=U;
L=zeros(4,Npoints(1),Nlayers);
I = diag(diag(ones(4,4)));
psi_ref=zeros(4,Npoints(1));psi_tra=psi_ref;
a_i=zeros(2,Npoints(1));a_r=a_i;a_t=a_i;
r_sp=zeros(length(inPlaneAngles),length(krs));
r_pp=r_sp;r_ps=r_sp;r_ss=r_sp;R_ss=r_sp;R_sp=r_sp;R_ps=r_sp;R_pp=r_sp;
t_sp=r_sp;t_pp=t_sp;t_ps=t_sp;t_ss=r_sp;T_ss=t_sp;T_sp=t_sp;T_ps=t_sp;T_pp=t_sp;
A_p=t_sp;A_s=t_sp;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% END CONFIGURATION VARIABLES %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% START OF TMM  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%% DO CHANGES ONLY IF YOU KNOW WHAT YOU ARE DOING :) %%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% select polarization
tic
h = waitbar(0,'Calculating scattering coefficients...');
for iIPA=1:length(inPlaneAngles)
    krs=krs+1e-12;%makes gamma point is avoided
    % inPlaneAngles=inPlaneAngles+1e-5;%makes gamma point is avoide
    if pol=='p'
        p_i_p=1;p_i_s=0;
    elseif pol=='s'
        p_i_p=0;p_i_s=1;
    else
        disp("Chose p or s polarization");
    end
    % incident wave vector
    k_first= sqrt(real(EPSR(1,1,1))/2*(sqrt(1+(imag(EPSR(1,1,1))/real(EPSR(1,1,1)))^2)+1)); % normalized k0 vector in first and last medium
    k_last = sqrt(real(EPSR(1,1,end))/2*(sqrt(1+(imag(EPSR(1,1,end))/real(EPSR(1,1,end)))^2)+1)); % normalized k0 vector in first and last medium
    % initialize momenta
    Qx=krs.*cosd(inPlaneAngles(iIPA));
    Qy=krs.*sind(inPlaneAngles(iIPA));
    QzF=sqrt(k_first^2-Qx.^2-Qy.^2).*(krs<=k_first)+1i*sqrt(Qx.^2+Qy.^2-k_first^2).*(krs>k_first);
    QzL=sqrt(k_last^2-Qx.^2-Qy.^2).*(krs<=k_last)+1i*sqrt(Qx.^2+Qy.^2-k_last^2).*(krs>k_last);
    % eigenbasis of first layer
    k_inc=[Qx;Qy;QzF];
    n = [0;0;-1]+0*k_inc;
    e_te_fw = -cross(n,real(k_inc))./vecnorm(cross(n,real(k_inc)));
    e_tm_fw = cross(real(k_inc),e_te_fw)./vecnorm(cross(real(k_inc),e_te_fw));
    % incident field vector
    E_inc=p_i_s*e_te_fw+p_i_p*e_tm_fw;
    h_inc=cross(k_inc,E_inc);
    psi_inc = [E_inc(1:2,:);h_inc(1:2,:)];
    norm_psi_inc = vecnorm(psi_inc);
    psi_inc=psi_inc./norm_psi_inc;
    %
    % system matrices
    for ii=1:Nlayers
        A_11 = -k_inc(1,:).*k_inc(2,:)-EPSR(2,1,ii)+EPSR(2,3,ii)*EPSR(3,1,ii)/EPSR(3,3,ii);
        A_12 = k_inc(1,:).^2-EPSR(2,2,ii)+EPSR(2,3,ii)*EPSR(3,2,ii)/EPSR(3,3,ii);
        A_21 = -k_inc(2,:).^2+EPSR(1,1,ii)-EPSR(1,3,ii)*EPSR(3,1,ii)/EPSR(3,3,ii);
        A_22 = k_inc(1,:).*k_inc(2,:)+EPSR(1,2,ii)-EPSR(1,3,ii)*EPSR(3,2,ii)/EPSR(3,3,ii);
        B_11 = k_inc(1,:).*k_inc(2,:)/EPSR(3,3,ii);
        B_12 = -k_inc(1,:).^2/EPSR(3,3,ii)+1;
        B_21 = k_inc(2,:).^2/EPSR(3,3,ii)-1;
        B_22 = -k_inc(1,:).*k_inc(2,:)/EPSR(3,3,ii);
        W_11 = -k_inc(1,:)*EPSR(3,1,ii)/EPSR(3,3,ii);
        W_12 = -k_inc(1,:)*EPSR(3,2,ii)/EPSR(3,3,ii);
        W_21 = -k_inc(2,:)*EPSR(3,1,ii)/EPSR(3,3,ii);
        W_22 = -k_inc(2,:)*EPSR(3,2,ii)/EPSR(3,3,ii);
        V_11 = -k_inc(2,:)*EPSR(2,3,ii)/EPSR(3,3,ii);
        V_12 = k_inc(1,:)*EPSR(2,3,ii)/EPSR(3,3,ii);
        V_21 = k_inc(2,:)*EPSR(1,3,ii)/EPSR(3,3,ii);
        V_22 = -k_inc(1,:)*EPSR(1,3,ii)/EPSR(3,3,ii);
        for jj=1:Npoints(1)
%             M_temp = round([[W_11(jj),W_12(jj);W_21(jj),W_22(jj)],[B_11(jj),B_12(jj);B_21(jj),B_22(jj)];
%                 [A_11(jj),A_12(jj);A_21(jj),A_22(jj)],[V_11(jj),V_12(jj);V_21(jj),V_22(jj)]],6);%*(real(k_inc(3))~=0)+...
            M_temp=[[W_11(jj),W_12(jj);W_21(jj),W_22(jj)],[B_11(jj),B_12(jj);B_21(jj),B_22(jj)];
            [A_11(jj),A_12(jj);A_21(jj),A_22(jj)],[V_11(jj),V_12(jj);V_21(jj),V_22(jj)]];

            [U_temp,L_temp]=eig(M_temp);
            l_real = real(diag(L_temp));
            l_imag = round(imag(diag(L_temp)),N_round);
            l_temp = l_real+1i*l_imag;
            % z component of poynting vector
            Pz= real(U_temp(1,:).*conj(U_temp(4,:))- U_temp(2,:).*conj(U_temp(3,:)))/Z0;
            if sum(abs(Pz))~=0
                [Pz_ord,ord] = sort(Pz,'descend'); % order Pz compontents in descendent mode
                l_temp = l_temp(ord);
                U_temp = U_temp(:,ord);
                if ii==Nlayers
                    U_temp = U_temp*(real(EPSR(1,1,end))==1)+U_temp(:,[2,1,3,4])*(real(EPSR(1,1,end))~=1);
                end
            else
                [l_imag_ord,ord] = sort(l_imag,'descend'); % order eigenvalues compontents in descendent mode
                l_temp = l_real(ord)+1i*l_imag_ord;
                U_temp = U_temp(:,ord);
            end
            %
            G_temp = diag(exp(1i*l_temp*k0*d(ii)));
            T_temp=U_temp*G_temp*pinv(U_temp);
            L(:,jj,ii)=l_temp;
            U(:,jj,ii)=[U_temp(:,1);U_temp(:,2);U_temp(:,3);U_temp(:,4)];
            G(:,jj,ii)=[G_temp(:,1);G_temp(:,2);G_temp(:,3);G_temp(:,4)];
            T(:,jj,ii)=[T_temp(:,1);T_temp(:,2);T_temp(:,3);T_temp(:,4)];
        end
    end
    clear U_temp G_temp T_temp l_temp
    %
    % reflected and refracted wave vector
    k_ref=[k_inc(1:2,:);L(3,:,1)];
    k_tra=[k_inc(1:2,:);L(1,:,end)];
    % reflected and refracted eigenbasis
    e_te_bw = -cross(n,k_ref)./vecnorm(cross(n,k_ref));
    e_tm_bw = cross(k_ref,e_te_bw)./vecnorm(cross(k_ref,e_te_bw));
    e_te_tra = cross(-n,k_tra)./vecnorm(cross(-n,k_tra));
    e_tm_tra = cross(k_tra,e_te_tra)./vecnorm(cross(k_tra,e_te_tra));
    %
    % solve TMM
    for ii=1:Npoints(1)
        if Nlayers==2
            U_temp_1=[U(1:4,ii,1),U(5:8,ii,1),U(9:12,ii,1),U(13:16,ii,1)];
            G_temp_1=[G(1:4,ii,1),G(5:8,ii,1),G(9:12,ii,1),G(13:16,ii,1)];
            U_temp_last=[U(1:4,ii,end),U(5:8,ii,end),U(9:12,ii,end),U(13:16,ii,end)];
            G_temp_last=[G(1:4,ii,end),G(5:8,ii,end),G(9:12,ii,end),G(13:16,ii,end)];
            P_temp=(G_temp_last*(pinv(U_temp_last)*(U_temp_1*G_temp_1)));
            a_p_1 = pinv(U_temp_1(:,1:2))*psi_inc(:,ii);
        elseif Nlayers>2
            U_temp_1=[U(1:4,ii,1),U(5:8,ii,1),U(9:12,ii,1),U(13:16,ii,1)];
            G_temp_1=[G(1:4,ii,1),G(5:8,ii,1),G(9:12,ii,1),G(13:16,ii,1)];
            a_p_1 = pinv(U_temp_1(:,1:2))*psi_inc(:,ii);
            P_temp=U_temp_1*G_temp_1;
            for jj=2:Nlayers-1
                U_temp=[U(1:4,ii,jj),U(5:8,ii,jj),U(9:12,ii,jj),U(13:16,ii,jj)];
                G_temp=[G(1:4,ii,jj),G(5:8,ii,jj),G(9:12,ii,jj),G(13:16,ii,jj)];
                P_temp=(U_temp*(G_temp*(pinv(U_temp)*P_temp)));
            end
            U_temp_last=[U(1:4,ii,end),U(5:8,ii,end),U(9:12,ii,end),U(13:16,ii,end)];
            G_temp_last=[G(1:4,ii,end),G(5:8,ii,end),G(9:12,ii,end),G(13:16,ii,end)];
            %
            P_temp=(G_temp_last*pinv(U_temp_last))*P_temp;
        else
            disp('Error! Please check: 1) number of layers; and 2) layer thickness.')
        end
        a_p_and_m =[I(:,1:2),-P_temp(:,3:4)]\(P_temp(:,1:2)*a_p_1);
        psi_ref(:,ii) = U_temp_1(:,3:4)*a_p_and_m(3:4);
        psi_tra(:,ii) = U_temp_last(:,1:2)*a_p_and_m(1:2);
        a_i(:,ii)=a_p_1;
        a_r(:,ii)=a_p_and_m(3:4);
        a_t(:,ii)=a_p_and_m(1:2);
    end
    %
    % calculate scattered fields
    psi_ref=psi_ref.*norm_psi_inc;
    psi_tra=psi_tra.*norm_psi_inc;
    E_ref = [psi_ref(1:2,:);zeros(1,Npoints)];
    E_ref(3,:) = -((k_ref(1,:)*EPSR(1,1,1)+k_ref(2,:)*EPSR(2,1,1)+k_ref(3,:)*EPSR(3,1,1)).*E_ref(1,:)+(k_ref(1,:)*EPSR(1,2,1)+k_ref(2,:)*EPSR(2,2,1)+k_ref(3,:)*EPSR(3,2,1)).*E_ref(2,:))./(k_ref(1,:)*EPSR(1,3,1)+k_ref(2,:)*EPSR(2,3,1)+k_ref(3,:)*EPSR(3,3,1));
    E_tra = [psi_tra(1:2,:);zeros(1,Npoints)];
    E_tra(3,:) = -((k_tra(1,:)*EPSR(1,1,end)+k_tra(2,:)*EPSR(2,1,end)+k_tra(3,:)*EPSR(3,1,end)).*E_tra(1,:)+(k_tra(1,:)*EPSR(1,2,end)+k_tra(2,:)*EPSR(2,2,end)+k_tra(3,:)*EPSR(3,2,end)).*E_tra(2,:))./(k_tra(1,:)*EPSR(1,3,end)+k_tra(2,:)*EPSR(2,3,end)+k_tra(3,:)*EPSR(3,3,end));
    % H_ref = [psi_ref(3:4,:);zeros(1,Npoints)];
    % H_ref(3,:) = -(k_ref(1,:).*H_ref(1,:)+k_ref(2,:).*H_ref(2,:))./k_ref(3,:);H_ref = H_ref/Z0;
    % H_tra = [psi_tra(3:4,:);zeros(1,Npoints)];
    % H_tra(3,:) = -(k_tra(1,:).*H_tra(1,:)+k_tra(2,:).*H_tra(2,:))./k_tra(3,:);H_tra = H_tra/Z0;
    %
    % calculate scattering coefficients
    p_r_s = dot(e_te_bw,E_ref); p_r_p = dot(e_tm_bw,E_ref); % reflected
    p_t_s = dot(e_te_tra,E_tra); p_t_p = dot(e_tm_tra,E_tra); % transmitted
    %
    if (p_i_p==1) % if input is p polarization
        r_sp(iIPA,:) = (p_r_s); r_pp(iIPA,:) = (p_r_p);
        t_sp(iIPA,:) = (p_t_s); t_pp(iIPA,:) = (p_t_p);
        R_sp(iIPA,:) = abs(r_sp(iIPA,:)).^2; R_pp(iIPA,:) = abs(r_pp(iIPA,:)).^2;
        T_sp(iIPA,:) = abs(t_sp(iIPA,:)).^2.*(real(k_tra(3,:))./real(k_inc(3,:))); T_pp = abs(t_pp(iIPA,:)).^2.*(real(k_tra(3,:))./real(k_inc(3,:)));
%         A_p = 1-R_pp-T_pp-(R_sp+T_sp); % this actual absorption considering cross-polarization
    else % else if input is s polarization
        r_ss(iIPA,:)= (p_r_s); r_ps(iIPA,:) = (p_r_p);
        t_ss(iIPA,:) = (p_t_s); t_ps(iIPA,:) = (p_t_p);
        R_ss(iIPA,:) = abs(r_ss(iIPA,:)).^2; R_ps(iIPA,:) = abs(r_ps(iIPA,:)).^2;
        T_ss(iIPA,:) = abs(t_ss(iIPA,:)).^2.*(real(k_tra(3,:))./real(k_inc(3,:))); T_ps(iIPA,:) = abs(t_ps(iIPA,:)).^2.*(real(k_tra(3,:))./real(k_inc(3,:)));
%         A_s = 1-R_ss-T_ss-(R_ps+T_ps); % this actual absorption considering cross-polarization
    end

    waitbar(iIPA/length(inPlaneAngles),h)
end
close(h)
toc
%
[KRS,IPAs]=meshgrid(krs,inPlaneAngles);
KX=KRS.*cosd(IPAs);
KY=KRS.*sind(IPAs);
%%
figure
surf(KX,KY,10*log10(R_pp)),shading flat
view([0,90])
%